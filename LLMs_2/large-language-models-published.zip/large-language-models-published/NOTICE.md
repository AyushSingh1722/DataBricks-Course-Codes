Copyright (2023) Databricks, Inc.

This Software includes software developed at Databricks (https://www.databricks.com/) and its use is subject to the included LICENSE file.

—-- This Software contains code from the following open source projects, licensed under the MIT license:

alvations/sacremoses - https://github.com/alvations/sacremoses Copyright 2022 alvations License - https://github.com/alvations/sacremoses/blob/master/LICENSE

openai/tiktoken - https://github.com/openai/tiktoken Copyright 2020 OpenAI, Shantanu Jain License - https://github.com/openai/tiktoken/blob/main/LICENSE

facebookresearch/faiss - https://github.com/facebookresearch/faiss Copyright Facebook, Inc. and its affiliates License - https://github.com/facebookresearch/faiss/blob/main/LICENSE

rileytomasek/pinecone-client - https://github.com/rileytomasek/pinecone-client Copyright 2022 Riley Tomasek License - https://github.com/rileytomasek/pinecone-client/blob/master/license

goldsmith/wikipedia - https://github.com/goldsmith/Wikipedia Copyright 2013 Jonathan Goldsmith LIcense - https://github.com/goldsmith/Wikipedia/blob/master/LICENSE

serpapi/google-search-results-python - https://github.com/serpapi/google-search-results-python Copyright 2018-2021 SerpApi License - https://github.com/serpapi/google-search-results-python/blob/master/LICENSE

snguyenthanh/better_profanity - https://github.com/snguyenthanh/better_profanity Copyright 2018 The Python Packaging Authority License - https://github.com/snguyenthanh/better_profanity/blob/master/LICENSE

workhorsy/py-cpuinfo - https://github.com/workhorsy/py-cpuinfo Copyright (2014-2022 Matthew Brennan Jones matthew.brennan.jones@gmail.com License - https://github.com/workhorsy/py-cpuinfo/blob/master/LICENSE

—-- This Software contains code from the following open source projects, licensed under the Apache 2.0 license:

JohnSnowLabs/nlptest - https://github.com/JohnSnowLabs/nlptest Copyright nlptest authors License - https://github.com/JohnSnowLabs/nlptest/blob/main/LICENSE

huggingface/disaggregators - https://github.com/huggingface/disaggregators Copyright disaggregators authors License - https://github.com/huggingface/disaggregators/blob/main/LICENSE

chroma-core/chroma - https://github.com/chroma-core/chroma Copyright chroma authors License - https://github.com/chroma-core/chroma/blob/main/LICENSE

pltrdy/rouge - https://github.com/pltrdy/rouge/tree/master Copyright rouge authors License - https://github.com/pltrdy/rouge/blob/master/LICENSE

microsoft/deepspeed - https://github.com/microsoft/DeepSpeed Copyright deepspeed authors License - https://github.com/microsoft/DeepSpeed/blob/master/LICENSE

—-- This Software contains code from the following open source projects, licensed under the BSD-3 license:

weaviate/weaviate-python-client - https://github.com/weaviate/weaviate-python-client Copyright (c) 2016-2023, Weaviate B.V. (registered @ Dutch Chamber of Commerce no 75231824) License - https://github.com/weaviate/weaviate-python-client/blob/main/LICENSE.md
