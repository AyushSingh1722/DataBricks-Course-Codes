Copyright (2023) Databricks, Inc.

This Software includes software developed at Databricks (https://www.databricks.com/) and its use is subject to the included LICENSE file.

—-- 
This Software contains code from the following open source projects, licensed under the Apache 2.0 license:

huggingface/peft -  https://github.com/huggingface/peft
Copyright 2022 Sourab Mangrulkar, Sylvain Gugger, Lysandre Debut, Younes Belkada, and Sayak Paul
License - https://github.com/huggingface/peft/blob/main/LICENSE

dmlc/decord - https://github.com/dmlc/decord
Copyright Decord authors
License - https://github.com/dmlc/decord/blob/master/LICENSE

—-- 
This Software contains code from the following open source projects, licensed under the MIT license:

sloria/textblob - https://github.com/sloria/TextBlob
Copyright 2013-2021 Steven Loria
License - https://github.com/sloria/TextBlob/blob/dev/LICENSE
